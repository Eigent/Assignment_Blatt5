
public class Main {
    public static void main(String[] args) {
        ListLinked myList = new ListLinked();
        myList.isEmpty(myList);
        myList.push("Peter");
        myList.push("Pan");
        myList.push("Albert");
        myList.push("Jörg");
        myList.push("Heike");
        myList.reverseString("test");
        myList.listContent();





        }
    }
